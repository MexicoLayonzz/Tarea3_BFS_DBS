import matplotlib.pyplot as plt
import networkx as nx
import time
from collections import deque

# Ciudad con más nodos
ciudad = {
    "A": ["B", "C", "D"],
    "B": ["A", "E", "F"],
    "C": ["A", "G"],
    "D": ["A", "H", "I"],
    "E": ["B", "J", "K"],
    "F": ["B", "L"],
    "G": ["C", "M"],
    "H": ["D", "N"],
    "I": ["D", "O", "P"],
    "J": ["E"],
    "K": ["E", "Q"],
    "L": ["F", "R"],
    "M": ["G"],
    "N": ["H"],
    "O": ["I"],
    "P": ["I"],
    "Q": ["K"],
    "R": ["L"],
}

# BFS
def bfs_ciudad(grafo, inicio, fin):
    cola = deque([(inicio, [inicio])])
    visitados = set([inicio])
    while cola:
        nodo, camino = cola.popleft()
        if nodo == fin:
            return camino
        for vecino in grafo[nodo]:
            if vecino not in visitados:
                cola.append((vecino, camino + [vecino]))
                visitados.add(vecino)
    return None

# DFS
def dfs_ciudad(grafo, inicio, fin):
    pila = [(inicio, [inicio])]
    visitados = set([inicio])
    while pila:
        nodo, camino = pila.pop()
        if nodo == fin:
            return camino
        for vecino in grafo[nodo]:
            if vecino not in visitados:
                pila.append((vecino, camino + [vecino]))
                visitados.add(vecino)
    return None

#Contador tiempos
start = time.time()
ruta_bfs = bfs_ciudad(ciudad, "A", "R")
t_bfs = time.time() - start

start = time.time()
ruta_dfs = dfs_ciudad(ciudad, "A", "R")
t_dfs = time.time() - start

print("Tiempo BFS en ciudad:", t_bfs, "segundos")
print("Tiempo DFS en ciudad:", t_dfs, "segundos")

#Vista gráfica
G = nx.Graph(ciudad)
pos = nx.spring_layout(G, seed=42)

plt.figure(figsize=(8,6))
nx.draw(G, pos, with_labels=True, node_size=700, node_color="lightgray")

if ruta_bfs:
    edges_bfs = list(zip(ruta_bfs, ruta_bfs[1:]))
    nx.draw_networkx_edges(G, pos, edgelist=edges_bfs, edge_color="blue", width=2, label="BFS")

if ruta_dfs:
    edges_dfs = list(zip(ruta_dfs, ruta_dfs[1:]))
    nx.draw_networkx_edges(G, pos, edgelist=edges_dfs, edge_color="red", style="dashed", width=2, label="DFS")

plt.title("Ciudad grande - BFS vs DFS")
plt.legend()
plt.show()
