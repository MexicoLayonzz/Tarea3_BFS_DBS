import matplotlib.pyplot as plt
import random, time
from collections import deque

# Generar un laberinto aleatorio 20x20
N = 20
random.seed(42) 
laberinto = [[0 if random.random() > 0.3 else 1 for _ in range(N)] for _ in range(N)]
laberinto[0][0] = 0
laberinto[N-1][N-1] = 0

inicio = (0, 0)
fin = (N-1, N-1)
direcciones = [(1,0), (-1,0), (0,1), (0,-1)]

# BFS
def bfs(laberinto, inicio, fin):
    filas, cols = len(laberinto), len(laberinto[0])
    cola = deque([(inicio, [inicio])])
    visitados = set([inicio])
    while cola:
        (x, y), camino = cola.popleft()
        if (x, y) == fin:
            return camino
        for dx, dy in direcciones:
            nx, ny = x + dx, y + dy
            if 0 <= nx < filas and 0 <= ny < cols and laberinto[nx][ny] == 0 and (nx, ny) not in visitados:
                cola.append(((nx, ny), camino + [(nx, ny)]))
                visitados.add((nx, ny))
    return None

# DFS
def dfs(laberinto, inicio, fin):
    filas, cols = len(laberinto), len(laberinto[0])
    pila = [(inicio, [inicio])]
    visitados = set([inicio])
    while pila:
        (x, y), camino = pila.pop()
        if (x, y) == fin:
            return camino
        for dx, dy in direcciones:
            nx, ny = x + dx, y + dy
            if 0 <= nx < filas and 0 <= ny < cols and laberinto[nx][ny] == 0 and (nx, ny) not in visitados:
                pila.append(((nx, ny), camino + [(nx, ny)]))
                visitados.add((nx, ny))
    return None

#Contador tiempos
start = time.time()
ruta_bfs = bfs(laberinto, inicio, fin)
t_bfs = time.time() - start

start = time.time()
ruta_dfs = dfs(laberinto, inicio, fin)
t_dfs = time.time() - start

print("Tiempo BFS en laberinto:", t_bfs, "segundos")
print("Tiempo DFS en laberinto:", t_dfs, "segundos")

#Vista gráfica
plt.figure(figsize=(7,7))
plt.imshow(laberinto, cmap="gray_r")

if ruta_bfs:
    x, y = zip(*ruta_bfs)
    plt.plot(y, x, color="blue", label="BFS (más corta)")
if ruta_dfs:
    x, y = zip(*ruta_dfs)
    plt.plot(y, x, color="red", linestyle="--", label="DFS")

plt.scatter(inicio[1], inicio[0], c="green", s=80, label="Inicio")
plt.scatter(fin[1], fin[0], c="gold", s=80, label="Meta")
plt.title("Laberinto 20x20 - BFS vs DFS")
plt.legend()
plt.gca().invert_yaxis()
plt.show()
